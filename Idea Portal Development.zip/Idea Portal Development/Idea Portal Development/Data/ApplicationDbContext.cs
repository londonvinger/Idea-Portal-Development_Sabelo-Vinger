﻿using Idea_Portal_Development.Models;
using Microsoft.EntityFrameworkCore;

namespace Idea_Portal_Development.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext>options) : base(options)
        {

        }
        public DbSet<Vehicle>vehicles { get; set; }
        public DbSet<Make> makes { get; set; }
        public DbSet<Model> models { get; set; }
    }
}
