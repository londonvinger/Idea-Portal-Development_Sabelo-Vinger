using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Idea_Portal_Development.Views.Home
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
