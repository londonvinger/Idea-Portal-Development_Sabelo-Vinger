﻿namespace Idea_Portal_Development.Models
{
    // Car class derived from Vehicle
    public class Car : Vehicle
    {
        public string AdditionalProperty1 { get; set; }
        public string AdditionalProperty2 { get; set; }

        public int MakeId { get; set; }
        public Make Make { get; set; }

        public int ModelId { get; set; }
        public Model Model { get; set; }
    }
}