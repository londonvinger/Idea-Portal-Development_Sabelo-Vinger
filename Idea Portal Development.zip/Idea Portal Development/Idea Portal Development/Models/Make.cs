﻿namespace Idea_Portal_Development.Models
{
    // Make class represents the make (manufacturer) of a vehicle.
    public class Make
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
