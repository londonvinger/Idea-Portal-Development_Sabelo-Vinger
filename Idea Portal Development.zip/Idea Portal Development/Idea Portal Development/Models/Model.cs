﻿namespace Idea_Portal_Development.Models
{
    // Model class represents the model of a vehicle.
    public class Model
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
