﻿namespace Idea_Portal_Development.Models
{
    // Vehicle class represents a basic vehicle.
    public class Vehicle
    {
        public int Id { get; set; }
        public string RegistrationNumber { get; set; }
        public string Color { get; set; }
        public double AverageSpeed { get; set; }

        public double CalculateDistanceTraveled(double hours, bool reverse = false)
        {
            double speed = reverse ? AverageSpeed * 0.1 : AverageSpeed;
            return speed * hours;
        }
    }
}